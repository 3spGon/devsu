package com.devsu.hackerearth.backend.account.exception;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Builder
public class ErrorDetails {
    private int status;
    private String message;
    private String detail;
    private LocalDateTime timestamp;
}
