package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.exception.EntityCreationException;
import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return accountRepository.findAll().stream().map(this::entityToDto).collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        return accountRepository.findById(id)
        .map(this::entityToDto)
        .orElseThrow(()-> new ResourceNotFoundException("Account not found"));
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account

        if(accountRepository.existsById(accountDto.getId()))
            throw new EntityCreationException("Account already exist");

        Account account = accountRepository.save(dtoToEntity(accountDto));
        return entityToDto(account);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
        if(!accountRepository.existsById(accountDto.getId()))
            throw new ResourceNotFoundException("Account not found");


        Account account = accountRepository.save(dtoToEntity(accountDto));
        accountRepository.save(account);
        return accountDto;
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
  
        Account account = accountRepository.findById(id)
                            .orElseThrow(()-> new ResourceNotFoundException("Account not found"));
        
        account.toBuilder()
        .isActive(partialAccountDto.isActive())
        .build();
        accountRepository.save(account);
        return entityToDto(account);
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        accountRepository.deleteById(id);
    }

    private AccountDto entityToDto(Account account){
        return AccountDto.builder()
                .id(account.getId())
                .number(account.getNumber())
                .type(account.getType())
                .initialAmount(account.getInitialAmount())
                .isActive(account.isActive())
                .clientId(account.getClientId())
                .build();
    }

    private Account dtoToEntity(AccountDto dto){
        return Account.builder()
                .id(dto.getId())
                .number(dto.getNumber())
                .type(dto.getType())
                .initialAmount(dto.getInitialAmount())
                .isActive(dto.isActive())
                .clientId(dto.getClientId())
                .build();
    }
}
