package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.exception.EntityCreationException;
import com.devsu.hackerearth.backend.client.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return clientRepository.findAll().stream().map(this::entityToDto).collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		return clientRepository.findById(id).map(this::entityToDto)
			.orElseThrow(()-> new ResourceNotFoundException("Client not found"));
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		try{
			// Create client
			Client client = clientRepository.save(dtoToEntity(clientDto));
			return entityToDto(client);
		}catch(Exception e){
			throw new EntityCreationException("Could not create the client:"+clientDto.toString());
		}
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client

		if(!clientRepository.existsById(clientDto.getId()))
			throw new ResourceNotFoundException("Client not found");

		Client client = dtoToEntity(clientDto);
		clientRepository.save(client);
		return clientDto;
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		if(!clientRepository.existsById(id))
			throw new ResourceNotFoundException("Client not found");

		Client originalClient = clientRepository.findById(id).get();
		originalClient.toBuilder()
		.isActive(partialClientDto.isActive())
		.build();
		return entityToDto(originalClient);
	}

	@Override
	public void deleteById(Long id) {
		// Delete client
		clientRepository.deleteById(id);
	}

	private ClientDto entityToDto(Client client) {
		return ClientDto.builder()
				.id(client.getId())
				.dni(client.getDni())
				.name(client.getName())
				.password(client.getPassword())
				.gender(client.getGender())
				.age(client.getAge())
				.address(client.getAddress())
				.phone(client.getPhone())
				.isActive(client.isActive())
				.build();
	}

	private Client dtoToEntity(ClientDto dto){
		return Client.builder()
				.id(dto.getId())
				.dni(dto.getDni())
				.name(dto.getName())
				.password(dto.getPassword())
				.gender(dto.getGender())
				.age(dto.getAge())
				.address(dto.getAddress())
				.phone(dto.getPhone())
				.isActive(dto.isActive())
				.build();
	}
}
